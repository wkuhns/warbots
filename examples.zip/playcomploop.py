x = 0       # Exercise Play Computer Loop
y = 1                  
for n in [5, 4, 6]:     
    x = x + y*n         
    y = y + 1                  
print(x)                
