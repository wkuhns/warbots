'''A very simple program,
showing how short a Python program can be!
Authors: ___, ___
'''

print('Hello world!')  #This is a stupid comment after the # mark
