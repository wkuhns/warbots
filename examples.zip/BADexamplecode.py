'''Code with PLANNED errors -- See 5.1 Using Error Messages.'''











x = input("Enter a number")
y = x + 10
print('10 more is {}'.format(y)
print('Now we are done!)
