def m(x):   # mathematical function m 
    return 5*x               
 
y = 3                         
print(m(y) + m(2*y-1))        
