outFile = open('sample.txt', 'w')
outFile.write('My first output file!')
outFile.close()
